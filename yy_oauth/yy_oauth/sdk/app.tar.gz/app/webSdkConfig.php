<?php

// 缓存udb key, 该文件由应用提供，需要保证PHP有对其的读写权限。

define("OAUTH_UDB_KEY_FILE","c:/key.dat");

//域名常量定义，会往顶级域名(如yy.com、duowan.com)写cookie
define("DOMAIN_DUOWAN", "lgn.duowan.com");
define("DOMAIN_YY", "lgn.yy.com");
define("DOMAIN_KUAIKUAI", "lgn.kuaikuai.cn");
define("DOMAIN_5253", "lgn.5253.cn");
define("DOMAIN_100", "lgn.100.com");
define("DOMAIN_1931", "lgn.1931.com");
define("DOMAIN_5153", "lgn.5153.com");
define("DOMAIN_YY_TV", "lgn.yy.tv");
define("DOMAIN_YY_CLOUDS", "lgn.yyclouds.com");
?>